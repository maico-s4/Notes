#!/usr/bin/python3
# -*- coding: utf-8 -*-
from tkinter import *
import getpass
import platform


class TkScreen:
    def __init__(self):
        self.tk = Tk()
        self.tk.wm_title("网格布局")
        self.tk.geometry("600x300+100+50")
        self.user_name = StringVar()
        self.user_name.set(getpass.getuser())
        self.pass_word = StringVar()
        self.pass_word.set(str(platform.system()) + ' | ' + str(platform.version()) + ' | '
                           + str(platform.architecture()))

        # 用 row 表示行，用 column 表示列，其中值得注意的是 row 和 column 的编号都从 0 开始。
        # grid 函数还有个 sticky 参数，它可以用 N， E， S， W 表示上右下左，它决定了这个组件是从哪个方向开始的，
        Label(self.tk, text="账号：").grid(row=0, sticky=W)
        Button(self.tk, text=chr(2295), font=('MS Gothic', '14')).grid(row=0, column=2, sticky=W)
        # Entry 表示“输入框
        Entry(self.tk, textvariable=self.user_name, width=30).grid(row=0, column=1, sticky=W)

        Label(self.tk, text="密码：").grid(row=1, sticky=W)
        Entry(self.tk, textvariable=self.pass_word, width=50, show='*').grid(row=1, column=1, sticky=W)

        Button(self.tk, text="登录", command=self.logon).grid(row=2, column=1, sticky=E)

    def show(self):
        # 主事件循环
        self.tk.mainloop()

    def logon(self):
        print('账号：' + self.user_name.get() + '\n' + '密码：' + self.pass_word.get())


def main():
    ts = TkScreen()
    ts.show()


if __name__ == '__main__':
    main()
