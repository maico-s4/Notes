#!/usr/bin/python3
# -*- coding: utf-8 -*-
from tkinter import *


class TkScreen:
    def __init__(self):
        self.tk = Tk()
        # 标签控件，显示文本和位图，展示在第一行
        Label(self.tk, text="First").grid(row=0)
        Label(self.tk, text="Second").grid(row=1)  # 第二行

    def show(self):
        # 主事件循环
        self.tk.mainloop()


def main():
    ts = TkScreen()
    ts.show()


if __name__ == '__main__':
    main()
